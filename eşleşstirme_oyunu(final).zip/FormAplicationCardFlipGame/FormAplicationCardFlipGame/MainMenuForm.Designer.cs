﻿namespace FormAplicationCardFlipGame
{
    partial class MainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EasyModeBtn = new System.Windows.Forms.Button();
            this.HardModeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EasyModeBtn
            // 
            this.EasyModeBtn.Location = new System.Drawing.Point(155, 109);
            this.EasyModeBtn.Name = "EasyModeBtn";
            this.EasyModeBtn.Size = new System.Drawing.Size(175, 95);
            this.EasyModeBtn.TabIndex = 1;
            this.EasyModeBtn.Text = "Kolay Mod";
            this.EasyModeBtn.UseVisualStyleBackColor = true;
            this.EasyModeBtn.Click += new System.EventHandler(this.EasyModeBtn_Click);
            // 
            // HardModeBtn
            // 
            this.HardModeBtn.Location = new System.Drawing.Point(439, 109);
            this.HardModeBtn.Name = "HardModeBtn";
            this.HardModeBtn.Size = new System.Drawing.Size(175, 95);
            this.HardModeBtn.TabIndex = 2;
            this.HardModeBtn.Text = "Zor Mod";
            this.HardModeBtn.UseVisualStyleBackColor = true;
            this.HardModeBtn.Click += new System.EventHandler(this.HardModeBtn_Click);
            // 
            // MainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.HardModeBtn);
            this.Controls.Add(this.EasyModeBtn);
            this.Name = "MainMenuForm";
            this.Text = "MainMenuForm";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button EasyModeBtn;
        private System.Windows.Forms.Button HardModeBtn;
    }
}